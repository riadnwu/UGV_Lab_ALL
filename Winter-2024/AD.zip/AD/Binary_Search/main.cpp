#include <iostream>

using namespace std;

int main()
{
    int st_id[3]={1001,1002,1003};
    string st_Name[3]={"1001","1002","1003"};

    cout<<st_Name[0]<<endl;
    return 0;
}
