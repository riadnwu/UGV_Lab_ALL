data=open("input.txt","rt")
id=open("id.txt","rt")
mark=open("mark.txt","rt")
data=data.read()
word=data.split(" ")
print(word)
id=id.read()
id=id.split()
mark=mark.read()
mark=mark.split()
length=len(word)
count=0
i=0;
html=""
while(count<length):
    if (word[count].find(id[i])!= -1):
        #print(word[count])
        html = html + ' ' + word[count]
        count = count + 1
        while(True):
            if(word[count].find("value=")!= -1):
                #print(word[count])
                html = html +'value="'+mark[i]+'"'
                count = count + 1
                break
            html = html + ' ' + word[count]
            count=count+1
        while (True) :
            if (word[count].find('type="checkbox"') != -1) :
                # print(word[count])
                html = html + ' ' + word[count]+' '+'checked="checked"'
                count = count + 1
                break
            html = html + ' ' + word[count]
            count = count + 1
        i+=1
    html =html+' '+word[count]
    count=count+1
#print(html)
output=open("output.txt","w")
output.write(html)